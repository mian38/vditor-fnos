#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vditor NAS 轻量服务器（安全增强版 · 多分区）
- 静态托管当前目录（index.html + vditor 前端资源，/vditor 公开）
- 文档分区：每个指定文件夹独立为一个“分区(root)”，分别列出其下 .md 文件
  * 来源优先级：VDITOR_DOC_DIRS(name::path 逗号分隔) → TRIM_DATA_SHARE_PATHS(飞牛访问权限)
    → 单目录回退(VDITOR_DOC_DIR / TRIM_PKGVAR/docs / BASE_DIR/docs)
- 访问控制（外网安全）：
  * 密码登录(PBKDF2-HMAC-SHA256)，HttpOnly+SameSite 会话 Cookie
  * 每客户端 IP 暴力破解锁定的登录失败计数 + 失败延迟 + 常量时间比较
  * 会话绑定真实 IP、空闲(30min)/绝对(8h)超时
  * 除登录/首次设置/公开静态资源外，所有 API 与上传文件均需登录
- 端口 / 监听地址 / 文档目录 / 密码 通过环境变量或配置目录配置

用法:
    python3 server.py
环境变量:
    VDITOR_PORT        监听端口 (默认 9000)
    VDITOR_HOST        监听地址 (默认 0.0.0.0)
    VDITOR_DOC_DIRS    多分区定义: 名称::路径,名称::路径 (优先)
    VDITOR_DOC_DIR     单目录回退 (默认 docs)
    VDITOR_DOC_NAME    单目录回退时的分区显示名 (默认 我的文档)
    TRIM_DATA_SHARE_PATHS  飞牛“访问权限”授权的文件夹路径(JSON数组或逗号/换行分隔)
    VDITOR_UPLOAD_DIR  上传文件存放目录
    VDITOR_PASSWORD    明文密码(部署时预设，推荐仅用于自动部署；否则用首次设置页)
    VDITOR_PWHASH      预置 PBKDF2 哈希(salt$iters$hash)，优先级高于 VDITOR_PASSWORD
    VDITOR_CONFIG      配置目录(存放 pwhash 文件)，默认 TRIM_PKGETC 或 BASE_DIR
    VDITOR_TRUST_PROXY 置 1 时信任 X-Forwarded-For 取真实客户端 IP(用于反暴力与绑定)
"""

import os
import re
import sys
import json
import time
import uuid
import hmac
import hashlib
import secrets
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote, parse_qs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------- 配置 ----------------
def load_config():
    cfg = {"PORT": "9000", "HOST": "0.0.0.0"}
    env_file = os.path.join(BASE_DIR, "config.env")
    if os.path.isfile(env_file):
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    port = int(os.environ.get("VDITOR_PORT", cfg.get("PORT", "9000")))
    host = os.environ.get("VDITOR_HOST", cfg.get("HOST", "0.0.0.0"))
    return host, port

HOST, PORT = load_config()

UPLOAD_DIR = os.environ.get("VDITOR_UPLOAD_DIR") or os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

CONFIG_DIR = os.environ.get("VDITOR_CONFIG") or os.environ.get("TRIM_PKGETC") or BASE_DIR
os.makedirs(CONFIG_DIR, exist_ok=True)

TRUST_PROXY = os.environ.get("VDITOR_TRUST_PROXY", "") in ("1", "true", "yes")

# ---------------- 安全常量 ----------------
PBKDF2_ITERS = 200000
IDLE_TIMEOUT = 1800        # 会话空闲超时（秒）30 分钟
ABS_TIMEOUT = 28800        # 会话绝对超时（秒）8 小时
MAX_FAIL = 5               # 锁定前最大失败次数
LOCK_WINDOW = 900          # 失败计数滑动窗口（秒）15 分钟
LOCK_DURATION = 900        # 锁定时长（秒）15 分钟
FAIL_DELAY = 0.15          # 登录失败人为延迟（秒），拖慢爆破

# ---------------- 密码哈希 ----------------
def make_pwhash(pw):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, PBKDF2_ITERS)
    return "%s$%d$%s$%s" % (
        "pbkdf2_sha256", PBKDF2_ITERS,
        salt.hex(), dk.hex(),
    )

def verify_pwhash(stored, pw):
    try:
        algo, iters_s, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        iters = int(iters_s)
        salt = bytes.fromhex(salt_hex)
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, iters)
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False

def load_pwhash():
    # 优先级：VDITOR_PWHASH > VDITOR_PASSWORD > pwhash 文件
    env_hash = os.environ.get("VDITOR_PWHASH", "").strip()
    if env_hash and "$" in env_hash:
        return env_hash, False  # (hash, needs_setup)
    env_pw = os.environ.get("VDITOR_PASSWORD", "").strip()
    if env_pw:
        return make_pwhash(env_pw), False
    pf = os.path.join(CONFIG_DIR, "pwhash")
    if os.path.isfile(pf):
        try:
            with open(pf, "r", encoding="utf-8") as f:
                h = f.read().strip()
            if h and "$" in h:
                return h, False
        except OSError:
            pass
    return None, True  # 需要首次设置密码

PWHASH, NEEDS_SETUP = load_pwhash()

def save_pwhash(h):
    pf = os.path.join(CONFIG_DIR, "pwhash")
    try:
        with open(pf, "w", encoding="utf-8") as f:
            f.write(h)
        try:
            os.chmod(pf, 0o600)
        except OSError:
            pass
        return True
    except OSError:
        return False

# ---------------- 会话与暴力防护（内存态）----------------
SESSIONS = {}        # token -> {ip, created, last}
FAIL_LOG = {}        # ip -> {fails, first, locked_until}

def client_ip(handler):
    if TRUST_PROXY:
        xff = handler.headers.get("X-Forwarded-For", "")
        if xff:
            return xff.split(",")[0].strip()
    return handler.client_address[0]

def get_session(handler):
    token = None
    c = handler.headers.get("Cookie", "")
    m = re.search(r"vditor_sid=([^;]+)", c or "")
    if m:
        token = m.group(1).strip()
    if not token or token not in SESSIONS:
        return None
    s = SESSIONS[token]
    now = time.time()
    ip = client_ip(handler)
    # IP 绑定 + 超时校验
    if s["ip"] != ip or (now - s["last"]) > IDLE_TIMEOUT or (now - s["created"]) > ABS_TIMEOUT:
        SESSIONS.pop(token, None)
        return None
    s["last"] = now
    return token

def start_session(handler):
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = {
        "ip": client_ip(handler),
        "created": time.time(),
        "last": time.time(),
    }
    return token

def end_session(handler):
    c = handler.headers.get("Cookie", "")
    m = re.search(r"vditor_sid=([^;]+)", c or "")
    if m:
        SESSIONS.pop(m.group(1).strip(), None)

def is_locked(ip):
    s = FAIL_LOG.get(ip)
    if not s:
        return False
    now = time.time()
    if s.get("locked_until", 0) > now:
        return True
    # 窗口外则清零
    if now - s.get("first", 0) > LOCK_WINDOW:
        FAIL_LOG.pop(ip, None)
        return False
    return False

def record_failure(ip):
    now = time.time()
    s = FAIL_LOG.get(ip)
    if not s or (now - s.get("first", 0) > LOCK_WINDOW):
        s = {"fails": 0, "first": now, "locked_until": 0}
        FAIL_LOG[ip] = s
    s["fails"] += 1
    if s["fails"] >= MAX_FAIL:
        s["locked_until"] = now + LOCK_DURATION
    return s

def record_success(ip):
    FAIL_LOG.pop(ip, None)

# ---------------- 文档分区 ----------------
def slugify(s):
    s = re.sub(r"[^a-zA-Z0-9\u4e00-\u9fa5_-]", "-", s or "").strip("-")
    return s or "root"

def parse_data_share_paths(raw):
    raw = (raw or "").strip()
    if not raw:
        return []
    try:
        obj = json.loads(raw)
        if isinstance(obj, list):
            return [str(x).strip() for x in obj if str(x).strip()]
        if isinstance(obj, dict):
            for k in ("paths", "data_share_paths", "list", "items"):
                if k in obj and isinstance(obj[k], list):
                    return [str(x).strip() for x in obj[k] if str(x).strip()]
            return [str(v).strip() for v in obj.values() if str(v).strip()]
    except Exception:
        pass
    # 飞牛 TRIM_DATA_SHARE_PATHS 常见为冒号分隔；亦兼容逗号/分号/换行。
    # 需还原 Windows 盘符（如 C:\a:C:\b 拆分后重组），Linux 路径不受影响。
    parts = re.split(r"[:,;\n]", raw)
    out = []
    i = 0
    while i < len(parts):
        p = parts[i].strip().strip('"').strip("'")
        if re.fullmatch(r"[A-Za-z]", p) and i + 1 < len(parts) and parts[i + 1].lstrip().startswith(("\\", "/")):
            out.append(p + ":" + parts[i + 1].lstrip())
            i += 2
            continue
        if p:
            out.append(p)
        i += 1
    return out


def read_share_paths_file(fp):
    """读取 share_paths 文件（飞牛“访问权限/手动配置”可能写入）：
       支持 JSON 数组、单行带引号路径、逐行路径。"""
    if not fp or not os.path.isfile(fp):
        return []
    try:
        with open(fp, "r", encoding="utf-8") as f:
            txt = f.read().strip()
    except OSError:
        return []
    if not txt:
        return []
    try:
        obj = json.loads(txt)
        if isinstance(obj, list):
            return [str(x).strip() for x in obj if str(x).strip()]
        if isinstance(obj, str):
            return [obj.strip()]
    except Exception:
        pass
    out = []
    for line in txt.splitlines():
        line = line.strip().strip('"').strip("'")
        if line:
            out.append(line)
    return out


def collect_share_paths():
    """收集可用文档分区来源（飞牛 / 自动）：
       1) TRIM_DATA_SHARE_PATHS（访问权限/共享工作区，冒号分隔）
       2) 本应用 config/resource 中 data-share 声明的共享目录（安装目录 shares/ 下的软链）
       3) 访问权限/手动配置写入的 share_paths 文件（TRIM_PKGVAR / PKGETC / PKGHOME）
       返回 [(显示名, 绝对路径), ...]
    """
    paths = []
    for p in parse_data_share_paths(os.environ.get("TRIM_DATA_SHARE_PATHS", "")):
        paths.append((os.path.basename(p.rstrip("/")) or "共享文件夹", p))
    appdest = os.environ.get("TRIM_APPDEST")
    if appdest:
        shares_dir = os.path.join(appdest, "shares")
        if os.path.isdir(shares_dir):
            for name in sorted(os.listdir(shares_dir)):
                fp = os.path.join(shares_dir, name)
                paths.append((name, fp))
    for base in (os.environ.get("TRIM_PKGVAR"), os.environ.get("TRIM_PKGETC"), os.environ.get("TRIM_PKGHOME")):
        if base:
            for p in read_share_paths_file(os.path.join(base, "share_paths")):
                paths.append((os.path.basename(p.rstrip("/")) or "共享文件夹", p))
    return paths


# 应用内手动管理的文件夹（持久化于配置目录 folders.json），保证“在应用内指定”可用
FOLDERS_FILE = os.path.join(CONFIG_DIR, "folders.json")


def load_managed_folders():
    if not os.path.isfile(FOLDERS_FILE):
        return []
    try:
        with open(FOLDERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [x for x in data if isinstance(x, dict) and x.get("path")]
    except Exception:
        pass
    return []


def save_managed_folders(lst):
    try:
        with open(FOLDERS_FILE, "w", encoding="utf-8") as f:
            json.dump(lst, f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


def build_doc_roots():
    roots = []
    dirs_env = os.environ.get("VDITOR_DOC_DIRS", "").strip()
    if dirs_env:
        # 显式多分区（name::path 逗号分隔），优先级最高，可在任意部署下使用
        for item in dirs_env.split(","):
            item = item.strip()
            if not item:
                continue
            if "::" in item:
                name, path = item.split("::", 1)
                name, path = name.strip(), path.strip()
            else:
                path = item
                name = os.path.basename(path.rstrip("/")) or "文档"
            if path:
                roots.append((name, path))
    else:
        # 飞牛：访问权限/共享工作区/手动配置目录
        for name, path in collect_share_paths():
            roots.append((name, path))
    # 应用内手动管理文件夹（WebUI 中添加，持久化）始终并入
    for f in load_managed_folders():
        p = (f.get("path") or "").strip()
        if not p:
            continue
        name = (f.get("name") or "").strip() or (os.path.basename(p.rstrip("/")) or "文档")
        roots.append((name, p))
    if not roots:
        # 回退：单目录（运行时数据 docs 或 BASE_DIR/docs）
        default = os.environ.get("VDITOR_DOC_DIR")
        if not default:
            base = os.environ.get("TRIM_PKGVAR")
            default = os.path.join(base, "docs") if base else os.path.join(BASE_DIR, "docs")
        name = os.environ.get("VDITOR_DOC_NAME", "我的文档")
        roots.append((name, default))
    # 去重（按绝对路径），生成最终分区列表
    out = []
    seen = set()
    for name, path in roots:
        abspath = os.path.abspath(path)
        if abspath in seen:
            continue
        seen.add(abspath)
        rid = slugify(name)
        if rid in {r["id"] for r in out}:
            rid = "%s-%d" % (rid, len(out))
        try:
            os.makedirs(abspath, exist_ok=True)
        except OSError:
            pass
        out.append({"id": rid, "name": name, "path": abspath})
    return out


DOC_ROOTS = build_doc_roots()
ROOT_MAP = {r["id"]: r for r in DOC_ROOTS}


def reload_doc_roots():
    global DOC_ROOTS, ROOT_MAP
    DOC_ROOTS = build_doc_roots()
    ROOT_MAP = {r["id"]: r for r in DOC_ROOTS}

# ---------------- MIME ----------------
EXTRA_MIME = {
    ".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css",
    ".svg": "image/svg+xml", ".woff": "font/woff", ".woff2": "font/woff2",
    ".ttf": "font/ttf", ".json": "application/json", ".wasm": "application/wasm",
    ".map": "application/json",
}

def guess_mime(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in EXTRA_MIME:
        return EXTRA_MIME[ext]
    mt, _ = mimetypes.guess_type(path)
    return mt or "application/octet-stream"

SEC_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
    "Content-Security-Policy": (
        "default-src 'self'; "
        # 允许外链图片（图床等），否则外部图片会被浏览器 CSP 拦截无法显示
        "img-src 'self' data: blob: https: http:; "
        "style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; "
        "font-src 'self' data:; "
        "connect-src 'self'"
    ),
}

def safe_join(base, path):
    """防止路径穿越，返回绝对路径或 None（跨平台安全）"""
    path = unquote(path).lstrip("/")
    base_abs = os.path.abspath(base)
    target = os.path.abspath(os.path.join(base_abs, path))
    if target == base_abs or target.startswith(base_abs + os.sep):
        return target
    return None

def parse_multipart(body, boundary):
    """极简 multipart/form-data 解析，兼容无 cgi 模块的 Python 3.13+"""
    files = []
    delim = b"--" + boundary
    parts = body.split(delim)
    for part in parts:
        if part in (b"", b"--", b"\r\n", b"--\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        idx = part.find(b"\r\n\r\n")
        if idx == -1:
            continue
        header = part[:idx].decode("utf-8", "replace")
        content = part[idx + 4:]
        cd = re.search(r"Content-Disposition:[^\r\n]*", header)
        if not cd:
            continue
        dispos = cd.group(0)
        name_m = re.search(r'name="([^"]*)"', dispos)
        file_m = re.search(r'filename="([^"]*)"', dispos)
        field = name_m.group(1) if name_m else None
        fname = file_m.group(1) if file_m else None
        if fname:
            files.append((field, fname, content))
    return files


class Handler(BaseHTTPRequestHandler):
    server_version = "VditorNAS/2.0"
    protocol_version = "HTTP/1.1"

    def _send(self, code, body=b"", headers=None):
        self.send_response(code)
        h = dict(SEC_HEADERS)
        if headers:
            h.update(headers)
        cookie = getattr(self, "_pending_cookie", None)
        if cookie:
            h["Set-Cookie"] = cookie
            self._pending_cookie = None
        for k, v in h.items():
            self.send_header(k, v)
        if "Content-Length" not in h:
            self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD" and body:
            self.wfile.write(body)

    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self._send(code, body, {"Content-Type": "application/json; charset=utf-8"})

    def _send_cookie(self, token):
        parts = ["vditor_sid=%s" % token, "HttpOnly", "SameSite=Lax", "Path=/", "Max-Age=%d" % ABS_TIMEOUT]
        proto = self.headers.get("X-Forwarded-Proto", "")
        if proto.lower() == "https" or os.environ.get("VDITOR_SECURE_COOKIE") == "1":
            parts.append("Secure")
        self._pending_cookie = "; ".join(parts)

    def _clear_cookie(self):
        self._pending_cookie = "vditor_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0"

    def _require_auth(self):
        """返回 True 表示已登录；否则已发送 401 并 return False"""
        if get_session(self) is None:
            self._send_json({"error": "unauthenticated", "code": 401}, 401)
            return False
        return True

    # ---------------- GET ----------------
    def do_GET(self):
        self._pending_cookie = None
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        # 公开：鉴权状态 / 首次设置状态
        if path == "/api/auth/check":
            self._send_json({"authenticated": get_session(self) is not None,
                             "needsSetup": NEEDS_SETUP})
            return
        if path == "/api/setup/status":
            self._send_json({"needsSetup": NEEDS_SETUP})
            return

        # 受限：文档/文件 API（需登录）
        if path == "/api/files":
            if not self._require_auth(): return
            self._api_list_files()
            return
        if path == "/api/file":
            if not self._require_auth(): return
            self._api_read_file(qs)
            return
        if path == "/api/folders":
            if not self._require_auth(): return
            self._api_folders()
            return

        if path == "/":
            path = "/index.html"

        # 已上传文件（需登录）
        if path.startswith("/uploads/"):
            if not self._require_auth(): return
            fp = safe_join(UPLOAD_DIR, path[len("/uploads/"):])
            if fp and os.path.isfile(fp):
                with open(fp, "rb") as f:
                    data = f.read()
                self._send(200, data, {"Content-Type": guess_mime(fp)})
            else:
                self._send(404, b"Not Found")
            return

        # 公开静态资源（含 /vditor 前端）
        fp = safe_join(BASE_DIR, path)
        if fp and os.path.isfile(fp):
            with open(fp, "rb") as f:
                data = f.read()
            self._send(200, data, {"Content-Type": guess_mime(fp)})
        else:
            self._send(404, b"Not Found")

    def do_HEAD(self):
        self.do_GET()

    # ---------------- POST ----------------
    def do_POST(self):
        self._pending_cookie = None
        parsed = urlparse(self.path)
        p = parsed.path

        # 登录 / 登出 / 首次设置：无需先登录
        if p == "/api/login":
            self._handle_login()
            return
        if p == "/api/logout":
            end_session(self)
            self._clear_cookie()
            self._send_json({"ok": True})
            return
        if p == "/api/setup":
            self._handle_setup()
            return

        # 以下接口均需登录
        if not self._require_auth(): return

        if p == "/api/save":
            self._api_save(parsed)
            return
        if p == "/api/new":
            self._api_new(parsed)
            return
        if p == "/api/upload":
            self._handle_upload()
            return
        if p == "/api/folders":
            self._api_folders_update()
            return
        self._send_json({"msg": "not found", "code": 404, "data": {}}, 404)

    # ---------------- 鉴权处理 ----------------
    def _handle_login(self):
        ip = client_ip(self)
        if is_locked(ip):
            self._send_json({"ok": False, "error": "账号已被锁定，请 %d 分钟后再试" % (LOCK_DURATION // 60)}, 423)
            return
        data = self._read_json()
        pw = data.get("password", "")
        ok = (PWHASH is not None) and verify_pwhash(PWHASH, pw)
        if ok:
            record_success(ip)
            token = start_session(self)
            self._send_cookie(token)
            self._send_json({"ok": True})
        else:
            record_failure(ip)
            time.sleep(FAIL_DELAY)  # 人为延迟，拖慢爆破
            self._send_json({"ok": False, "error": "密码错误"}, 401)

    def _handle_setup(self):
        global PWHASH, NEEDS_SETUP
        # 仅当尚未设置密码时允许首次设置；已设置后该接口不可用（改密需登录后另做）
        if not NEEDS_SETUP and PWHASH is not None:
            self._send_json({"ok": False, "error": "已初始化，无法重复设置"}, 403)
            return
        data = self._read_json()
        pw = data.get("password", "")
        if not pw or len(pw) < 6:
            self._send_json({"ok": False, "error": "密码至少 6 位"}, 400)
            return
        h = make_pwhash(pw)
        if not save_pwhash(h):
            self._send_json({"ok": False, "error": "写入密码文件失败"}, 500)
            return
        PWHASH = h
        NEEDS_SETUP = False
        token = start_session(self)
        self._send_cookie(token)
        self._send_json({"ok": True})

    def _handle_upload(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b""
        ctype = self.headers.get("Content-Type", "")
        m = re.search(r"boundary=([^;]+)", ctype)
        if not m:
            self._send_json({"msg": "bad request", "code": 1, "data": {}}, 400)
            return
        boundary = m.group(1).strip().strip('"').encode("utf-8")
        succ_map = {}
        err_files = []
        try:
            files = parse_multipart(body, boundary)
            for field, fname, content in files:
                ext = os.path.splitext(fname)[1]
                if len(ext) > 10:
                    ext = ""
                store_name = uuid.uuid4().hex + ext
                out_path = os.path.join(UPLOAD_DIR, store_name)
                with open(out_path, "wb") as f:
                    f.write(content)
                succ_map[fname] = "/uploads/" + store_name
        except Exception as e:
            self._send_json({"msg": str(e), "code": 1, "data": {"errFiles": err_files, "succMap": succ_map}})
            return
        self._send_json({"msg": "", "code": 0, "data": {"errFiles": err_files, "succMap": succ_map}})

    # ---------------- 文档管理（多分区）----------------
    def _read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b""
        return json.loads(raw.decode("utf-8")) if raw else {}

    def _find_root(self, root_id):
        return ROOT_MAP.get(root_id)

    def _safe_doc(self, root_id, rel):
        root = self._find_root(root_id)
        if not root or not rel:
            return None
        rel = rel.lstrip("/")
        if not rel.lower().endswith(".md"):
            rel = rel + ".md"
        return safe_join(root["path"], rel)

    def _rel(self, root_path, fp):
        return os.path.relpath(fp, root_path).replace(os.sep, "/")

    # ---------------- 文件夹管理（应用内指定可访问文件夹）----------------
    def _api_folders(self):
        self._send_json({
            "managed": load_managed_folders(),
            "roots": [{"id": r["id"], "name": r["name"], "path": r["path"]} for r in DOC_ROOTS],
        })

    def _api_folders_update(self):
        try:
            data = self._read_json()
        except Exception:
            self._send_json({"ok": False, "error": "bad json"}, 400)
            return
        action = data.get("action")
        lst = load_managed_folders()
        if action == "add":
            name = (data.get("name") or "").strip()
            path = (data.get("path") or "").strip()
            if not path:
                self._send_json({"ok": False, "error": "路径不能为空"}, 400)
                return
            ap = os.path.abspath(path)
            if any(os.path.abspath(x.get("path", "")) == ap for x in lst):
                self._send_json({"ok": False, "error": "该文件夹已添加"}, 409)
                return
            if not name:
                name = os.path.basename(path.rstrip("/")) or "文档"
            lst.append({"name": name, "path": path})
            if not save_managed_folders(lst):
                self._send_json({"ok": False, "error": "保存失败"}, 500)
                return
            reload_doc_roots()
            self._send_json({"ok": True, "managed": load_managed_folders(),
                            "roots": [{"id": r["id"], "name": r["name"], "path": r["path"]} for r in DOC_ROOTS]})
        elif action == "remove":
            path = (data.get("path") or "").strip()
            if not path:
                self._send_json({"ok": False, "error": "路径不能为空"}, 400)
                return
            ap = os.path.abspath(path)
            newlst = [x for x in lst if os.path.abspath(x.get("path", "")) != ap]
            if len(newlst) == len(lst):
                self._send_json({"ok": False, "error": "未找到该文件夹"}, 404)
                return
            save_managed_folders(newlst)
            reload_doc_roots()
            self._send_json({"ok": True, "managed": load_managed_folders(),
                            "roots": [{"id": r["id"], "name": r["name"], "path": r["path"]} for r in DOC_ROOTS]})
        else:
            self._send_json({"ok": False, "error": "未知操作"}, 400)

    def _api_list_files(self):
        roots = []
        for r in DOC_ROOTS:
            files = []
            base = r["path"]
            if os.path.isdir(base):
                for root, dirs, names in os.walk(base):
                    for n in names:
                        if n.lower().endswith(".md"):
                            full = os.path.join(root, n)
                            try:
                                st = os.stat(full)
                                files.append({
                                    "root": r["id"],
                                    "name": n,
                                    "path": self._rel(base, full),
                                    "mtime": int(st.st_mtime),
                                    "size": st.st_size,
                                })
                            except OSError:
                                continue
            files.sort(key=lambda x: x["name"].lower())
            roots.append({
                "id": r["id"], "name": r["name"], "path": base,
                "exists": os.path.isdir(base), "files": files,
            })
        self._send_json({"roots": roots})

    def _api_read_file(self, qs):
        root_id = (qs.get("root") or [""])[0]
        rel = (qs.get("path") or [""])[0]
        fp = self._safe_doc(root_id, rel)
        root = self._find_root(root_id)
        if not fp or not root or not os.path.isfile(fp):
            self._send_json({"error": "not found"}, 404)
            return
        try:
            with open(fp, "r", encoding="utf-8") as f:
                content = f.read()
        except OSError as e:
            self._send_json({"error": str(e)}, 500)
            return
        self._send_json({"root": root_id, "path": self._rel(root["path"], fp),
                         "name": os.path.basename(fp), "content": content})

    def _api_save(self, parsed):
        try:
            data = self._read_json()
        except Exception:
            self._send_json({"ok": False, "error": "bad json"}, 400)
            return
        root_id = data.get("root", "")
        rel = data.get("path", "")
        content = data.get("content", "")
        fp = self._safe_doc(root_id, rel)
        root = self._find_root(root_id)
        if not fp or not root:
            self._send_json({"ok": False, "error": "invalid path"}, 400)
            return
        try:
            parent = os.path.dirname(fp)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(fp, "w", encoding="utf-8") as f:
                f.write(content)
            st = os.stat(fp)
            self._send_json({"ok": True, "root": root_id, "path": self._rel(root["path"], fp), "mtime": int(st.st_mtime)})
        except OSError as e:
            self._send_json({"ok": False, "error": str(e)}, 500)

    def _api_new(self, parsed):
        try:
            data = self._read_json()
        except Exception:
            self._send_json({"ok": False, "error": "bad json"}, 400)
            return
        root_id = data.get("root", "")
        rel = data.get("path", "")
        fp = self._safe_doc(root_id, rel)
        root = self._find_root(root_id)
        if not fp or not root:
            self._send_json({"ok": False, "error": "invalid path"}, 400)
            return
        if os.path.exists(fp):
            self._send_json({"ok": False, "error": "exists"}, 409)
            return
        try:
            if os.path.dirname(fp):
                os.makedirs(os.path.dirname(fp), exist_ok=True)
            with open(fp, "w", encoding="utf-8") as f:
                f.write("")
            self._send_json({"ok": True, "root": root_id, "path": self._rel(root["path"], fp)})
        except OSError as e:
            self._send_json({"ok": False, "error": str(e)}, 500)

    def log_message(self, fmt, *args):
        sys.stderr.write("[vditor-nas] %s - %s\n" % (self.address_string(), fmt % args))


def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("=" * 56)
    print(" Vditor NAS 已启动（安全增强版）")
    print(" 监听地址 : http://%s:%d" % (HOST, PORT))
    print(" 本机访问 : http://127.0.0.1:%d" % PORT)
    print(" 资源目录 : %s" % BASE_DIR)
    print(" 上传目录 : %s" % UPLOAD_DIR)
    print(" 文档分区 :")
    for r in DOC_ROOTS:
        print("   - [%s] %s" % (r["name"], r["path"]))
    if NEEDS_SETUP:
        print(" 安全提示 : 首次访问需设置管理员密码（/api/setup）")
    else:
        print(" 访问控制 : 已启用密码登录")
    if not TRUST_PROXY:
        print(" 代理提示 : 若经反向代理/内网穿透，请设置 VDITOR_TRUST_PROXY=1 以正确识别客户端 IP")
    print(" 按 Ctrl+C 停止")
    print("=" * 56)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n正在关闭...")
        server.shutdown()


if __name__ == "__main__":
    main()
